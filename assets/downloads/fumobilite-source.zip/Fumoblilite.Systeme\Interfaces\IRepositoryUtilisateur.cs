using System.Collections.Generic;
using Fumoblilite.Systeme.Modeles;

namespace Fumoblilite.Systeme.Interfaces
{
    /// <summary>
    /// Interface pour la gestion des op�rations sur les utilisateurs.
    /// </summary>
    public interface IRepositoryUtilisateur
    {
        /// <summary>
        /// R�cup�re la liste de tous les utilisateurs.
        /// </summary>
        /// <returns>Liste de tous les utilisateurs.</returns>
        List<Utilisateur> ObtenirTous();

        /// <summary>
        /// R�cup�re un utilisateur par son identifiant unique.
        /// </summary>
        /// <param name="id">Identifiant de l'utilisateur.</param>
        /// <returns>L'utilisateur correspondant ou null si non trouv�.</returns>
        Utilisateur ObtenirParId(int id);

        /// <summary>
        /// R�cup�re un utilisateur par son nom d'utilisateur (pseudo).
        /// </summary>
        /// <param name="nomUtilisateur">Nom d'utilisateur (pseudo).</param>
        /// <returns>L'utilisateur correspondant ou null si non trouv�.</returns>
        Utilisateur ObtenirParNomUtilisateur(string nomUtilisateur);

        /// <summary>
        /// Ajoute un nouvel utilisateur.
        /// </summary>
        /// <param name="utilisateur">Utilisateur � ajouter.</param>
        /// <returns>L'identifiant du nouvel utilisateur ajout�.</returns>
        int Ajouter(Utilisateur utilisateur);

        /// <summary>
        /// Modifie les informations d'un utilisateur existant.
        /// </summary>
        /// <param name="utilisateur">Utilisateur avec les nouvelles informations.</param>
        /// <returns>True si la modification a r�ussi, sinon false.</returns>
        bool Modifier(Utilisateur utilisateur);

        /// <summary>
        /// Modifie le mot de passe d'un utilisateur.
        /// </summary>
        /// <param name="id">Identifiant de l'utilisateur.</param>
        /// <param name="motDePasse">Nouveau mot de passe.</param>
        /// <returns>True si la modification a r�ussi, sinon false.</returns>
        bool ModifierMotDePasse(int id, string motDePasse);

        /// <summary>
        /// Supprime un utilisateur par son identifiant.
        /// </summary>
        /// <param name="id">Identifiant de l'utilisateur � supprimer.</param>
        /// <returns>True si la suppression a r�ussi, sinon false.</returns>
        bool Supprimer(int id);
    }
}

