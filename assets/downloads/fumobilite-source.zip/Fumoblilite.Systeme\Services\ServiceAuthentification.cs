using System;
using System.Security.Cryptography;
using System.Text;
using Fumoblilite.Systeme.Modeles;
using Fumoblilite.Systeme.Interfaces;

namespace Fumoblilite.Systeme.Services
{
    /// <summary>
    /// Service g�rant l'authentification des utilisateurs.
    /// </summary>
    public class ServiceAuthentification
    {
        /// <summary>
        /// R�f�rence au d�p�t des utilisateurs.
        /// </summary>
        private readonly IRepositoryUtilisateur _repositoryUtilisateur;

        /// <summary>
        /// Initialise une nouvelle instance du service d'authentification.
        /// </summary>
        /// <param name="repositoryUtilisateur">D�p�t des utilisateurs.</param>
        public ServiceAuthentification(IRepositoryUtilisateur repositoryUtilisateur)
        {
            _repositoryUtilisateur = repositoryUtilisateur;
        }

        /// <summary>
        /// Authentifie un utilisateur � partir de son nom d'utilisateur et de son mot de passe.
        /// </summary>
        /// <param name="nomUtilisateur">Nom d'utilisateur.</param>
        /// <param name="motDePasse">Mot de passe en clair.</param>
        /// <returns>L'utilisateur authentifi� ou null si l'authentification �choue.</returns>
        public Utilisateur Authentifier(string nomUtilisateur, string motDePasse)
        {
            if (string.IsNullOrEmpty(nomUtilisateur) || string.IsNullOrEmpty(motDePasse))
                return null;

            var utilisateur = _repositoryUtilisateur.ObtenirParNomUtilisateur(nomUtilisateur);
            if (utilisateur == null || !utilisateur.EstActif)
                return null;

            string motDePasseHash = HashMotDePasse(motDePasse);
            if (utilisateur.MotDePasse != motDePasseHash)
                return null;

            return utilisateur;
        }

        /// <summary>
        /// Calcule le hash SHA256 d'un mot de passe.
        /// </summary>
        /// <param name="motDePasse">Mot de passe en clair.</param>
        /// <returns>Hash du mot de passe sous forme de cha�ne hexad�cimale.</returns>
        public string HashMotDePasse(string motDePasse)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(motDePasse));
                StringBuilder builder = new StringBuilder();
                for (int i = 0; i < bytes.Length; i++)
                {
                    builder.Append(bytes[i].ToString("x2"));
                }
                return builder.ToString();
            }
        }
    }
}

