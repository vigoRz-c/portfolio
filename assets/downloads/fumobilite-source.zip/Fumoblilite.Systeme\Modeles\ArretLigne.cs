using System;

namespace Fumoblilite.Systeme.Modeles
{
    /// <summary>
    /// Mod�le de donn�es pour un arr�t de ligne.
    /// </summary>
    public class ArretLigne
    {
        public int Id { get; set; } // Identifiant de l'arr�t de ligne
        public int LigneId { get; set; } // Identifiant de la ligne
        public int ArretId { get; set; } // Identifiant de l'arr�t
        public int Ordre { get; set; } // Ordre de l'arr�t sur la ligne
        public int TempsArretMinutes { get; set; } // Temps d'arr�t en minutes
        public int TempsTrajetSuivantMinutes { get; set; } // Temps de trajet jusqu'au prochain arr�t en minutes
        public Arret Arret { get; set; } // D�tails de l'arr�t
        public DateTime DateCreation { get; set; } // Date de cr�ation de l'arr�t de ligne
        public DateTime? DateModification { get; set; } // Date de modification de l'arr�t de ligne

        /// <summary>
        /// Constructeur par d�faut.
        /// Initialise la date de cr�ation � la date et l'heure actuelles.
        /// </summary>
        public ArretLigne()
        {
            DateCreation = DateTime.Now;
        }

        /// <summary>
        /// Constructeur avec param�tres.
        /// Initialise les propri�t�s de l'arr�t de ligne avec les valeurs fournies.
        /// </summary>
        /// <param name="id">Identifiant de l'arr�t de ligne.</param>
        /// <param name="ligneId">Identifiant de la ligne.</param>
        /// <param name="arretId">Identifiant de l'arr�t.</param>
        /// <param name="ordre">Ordre de l'arr�t sur la ligne.</param>
        /// <param name="tempsArretMinutes">Temps d'arr�t en minutes.</param>
        /// <param name="tempsTrajetSuivantMinutes">Temps de trajet jusqu'au prochain arr�t en minutes.</param>
        public ArretLigne(int id, int ligneId, int arretId, int ordre, int tempsArretMinutes, int tempsTrajetSuivantMinutes)
        {
            Id = id;
            LigneId = ligneId;
            ArretId = arretId;
            Ordre = ordre;
            TempsArretMinutes = tempsArretMinutes;
            TempsTrajetSuivantMinutes = tempsTrajetSuivantMinutes;
            DateCreation = DateTime.Now;
        }
    }
}

