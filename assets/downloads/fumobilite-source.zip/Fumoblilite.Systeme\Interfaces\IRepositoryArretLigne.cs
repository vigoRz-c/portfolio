using System.Collections.Generic;
using Fumoblilite.Systeme.Modeles;

namespace Fumoblilite.Systeme.Interfaces
{
    /// <summary>
    /// Interface pour la gestion des op�rations sur les arr�ts de ligne.
    /// </summary>
    public interface IRepositoryArretLigne
    {
        /// <summary>
        /// R�cup�re la liste des arr�ts de ligne pour une ligne donn�e.
        /// </summary>
        /// <param name="ligneId">Identifiant de la ligne.</param>
        /// <returns>Liste des arr�ts de ligne associ�s � la ligne.</returns>
        List<ArretLigne> ObtenirParLigne(int ligneId);

        /// <summary>
        /// R�cup�re un arr�t de ligne par son identifiant.
        /// </summary>
        /// <param name="id">Identifiant de l'arr�t de ligne.</param>
        /// <returns>L'arr�t de ligne correspondant ou null si non trouv�.</returns>
        ArretLigne ObtenirParId(int id);

        /// <summary>
        /// Ajoute un nouvel arr�t de ligne.
        /// </summary>
        /// <param name="arretLigne">L'arr�t de ligne � ajouter.</param>
        /// <returns>L'identifiant de l'arr�t de ligne ajout�.</returns>
        int Ajouter(ArretLigne arretLigne);

        /// <summary>
        /// Modifie un arr�t de ligne existant.
        /// </summary>
        /// <param name="arretLigne">L'arr�t de ligne � modifier.</param>
        /// <returns>True si la modification a r�ussi, sinon false.</returns>
        bool Modifier(ArretLigne arretLigne);

        /// <summary>
        /// Supprime un arr�t de ligne par son identifiant.
        /// </summary>
        /// <param name="id">Identifiant de l'arr�t de ligne � supprimer.</param>
        /// <returns>True si la suppression a r�ussi, sinon false.</returns>
        bool Supprimer(int id);
    }
}

