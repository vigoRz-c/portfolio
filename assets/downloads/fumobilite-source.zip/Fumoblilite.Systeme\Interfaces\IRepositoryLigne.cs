using System.Collections.Generic;
using Fumoblilite.Systeme.Modeles;

namespace Fumoblilite.Systeme.Interfaces
{
    /// <summary>
    /// Interface pour la gestion des op�rations CRUD sur les entit�s Ligne.
    /// </summary>
    public interface IRepositoryLigne
    {
        /// <summary>
        /// R�cup�re la liste de toutes les lignes.
        /// </summary>
        /// <returns>Liste de toutes les lignes.</returns>
        List<Ligne> ObtenirToutes();

        /// <summary>
        /// R�cup�re une ligne par son identifiant.
        /// </summary>
        /// <param name="id">Identifiant de la ligne.</param>
        /// <returns>La ligne correspondante ou null si non trouv�e.</returns>
        Ligne ObtenirParId(int id);

        /// <summary>
        /// Ajoute une nouvelle ligne.
        /// </summary>
        /// <param name="ligne">Ligne � ajouter.</param>
        /// <returns>Identifiant de la ligne ajout�e.</returns>
        int Ajouter(Ligne ligne);

        /// <summary>
        /// Modifie une ligne existante.
        /// </summary>
        /// <param name="ligne">Ligne � modifier.</param>
        /// <returns>True si la modification a r�ussi, sinon false.</returns>
        bool Modifier(Ligne ligne);

        /// <summary>
        /// Supprime une ligne par son identifiant.
        /// </summary>
        /// <param name="id">Identifiant de la ligne � supprimer.</param>
        /// <returns>True si la suppression a r�ussi, sinon false.</returns>
        bool Supprimer(int id);
    }
}

