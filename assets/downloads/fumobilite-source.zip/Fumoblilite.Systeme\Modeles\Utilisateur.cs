using System;

namespace Fumoblilite.Systeme.Modeles
{
    /// <summary>
    /// Mod�le de donn�es pour un utilisateur.
    /// </summary>
    public class Utilisateur
    {
        /// <summary>
        /// Identifiant de l'utilisateur.
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Nom de l'utilisateur.
        /// </summary>
        public string Nom { get; set; }

        /// <summary>
        /// Pr�nom de l'utilisateur.
        /// </summary>
        public string Prenom { get; set; }

        /// <summary>
        /// Pseudo de l'utilisateur.
        /// </summary>
        public string NomUtilisateur { get; set; }

        /// <summary>
        /// Mot de passe de l'utilisateur.
        /// </summary>
        public string MotDePasse { get; set; }

        /// <summary>
        /// Email de l'utilisateur.
        /// </summary>
        public string Email { get; set; }

        /// <summary>
        /// R�le de l'utilisateur (Admin ou Utilisateur).
        /// </summary>
        public string Role { get; set; }

        /// <summary>
        /// Statut de l'utilisateur (actif ou non).
        /// </summary>
        public bool EstActif { get; set; }

        /// <summary>
        /// Date de cr�ation de l'utilisateur.
        /// </summary>
        public DateTime DateCreation { get; set; }

        /// <summary>
        /// Date de modification de l'utilisateur.
        /// </summary>
        public DateTime? DateModification { get; set; }

        /// <summary>
        /// Constructeur par d�faut. Initialise la date de cr�ation et le statut actif.
        /// </summary>
        public Utilisateur()
        {
            DateCreation = DateTime.Now;
            EstActif = true;
        }

        /// <summary>
        /// Constructeur avec param�tres pour initialiser toutes les propri�t�s principales.
        /// </summary>
        /// <param name="id">Identifiant de l'utilisateur.</param>
        /// <param name="nom">Nom de l'utilisateur.</param>
        /// <param name="prenom">Pr�nom de l'utilisateur.</param>
        /// <param name="nomUtilisateur">Pseudo de l'utilisateur.</param>
        /// <param name="motDePasse">Mot de passe de l'utilisateur.</param>
        /// <param name="email">Email de l'utilisateur.</param>
        /// <param name="role">R�le de l'utilisateur.</param>
        public Utilisateur(int id, string nom, string prenom, string nomUtilisateur, string motDePasse, string email, string role)
        {
            Id = id;
            Nom = nom;
            Prenom = prenom;
            NomUtilisateur = nomUtilisateur;
            MotDePasse = motDePasse;
            Email = email;
            Role = role;
            EstActif = true;
            DateCreation = DateTime.Now;
        }
    }
}

