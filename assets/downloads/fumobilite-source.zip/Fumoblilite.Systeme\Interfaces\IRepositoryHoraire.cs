using System;
using System.Collections.Generic;
using Fumoblilite.Systeme.Modeles;

namespace Fumoblilite.Systeme.Interfaces
{
    /// <summary>
    /// Interface pour la gestion des horaires dans le syst�me.
    /// </summary>
    public interface IRepositoryHoraire
    {
        /// <summary>
        /// Obtient la liste des horaires pour une ligne donn�e.
        /// </summary>
        /// <param name="ligneId">Identifiant de la ligne.</param>
        /// <returns>Liste des horaires.</returns>
        List<Horaire> ObtenirParLigne(int ligneId);

        /// <summary>
        /// Obtient la liste des horaires pour un arr�t donn�.
        /// </summary>
        /// <param name="arretId">Identifiant de l'arr�t.</param>
        /// <returns>Liste des horaires.</returns>
        List<Horaire> ObtenirParArret(int arretId);

        /// <summary>
        /// Obtient la liste des horaires pour une ligne et un jour donn�s.
        /// </summary>
        /// <param name="ligneId">Identifiant de la ligne.</param>
        /// <param name="jour">Jour de la semaine.</param>
        /// <returns>Liste des horaires.</returns>
        List<Horaire> ObtenirParLigneEtJour(int ligneId, DayOfWeek jour);

        /// <summary>
        /// Obtient la liste des horaires pour un arr�t et un jour donn�s.
        /// </summary>
        /// <param name="arretId">Identifiant de l'arr�t.</param>
        /// <param name="jour">Jour de la semaine.</param>
        /// <returns>Liste des horaires.</returns>
        List<Horaire> ObtenirParArretEtJour(int arretId, DayOfWeek jour);

        /// <summary>
        /// Obtient la liste des horaires pour un jour donn�.
        /// </summary>
        /// <param name="jour">Jour de la semaine.</param>
        /// <returns>Liste des horaires.</returns>
        List<Horaire> ObtenirParJour(DayOfWeek jour);

        // Nouvelles m�thodes optimis�es

        /// <summary>
        /// Obtient la liste des horaires selon des crit�res avanc�s.
        /// </summary>
        /// <param name="criteres">Crit�res de recherche.</param>
        /// <returns>Liste des horaires.</returns>
        List<Horaire> ObtenirParCriteres(HoraireCriteres criteres);

        /// <summary>
        /// Obtient les prochains horaires pour un arr�t � partir d'une date/heure donn�e.
        /// </summary>
        /// <param name="arretId">Identifiant de l'arr�t.</param>
        /// <param name="dateHeure">Date et heure de r�f�rence.</param>
        /// <param name="limite">Nombre maximum de r�sultats � retourner.</param>
        /// <returns>Liste des horaires.</returns>
        List<Horaire> ObtenirProchains(int arretId, DateTime dateHeure, int limite = 10);

        /// <summary>
        /// Obtient la liste des horaires pour une ligne, un jour et une plage horaire donn�s.
        /// </summary>
        /// <param name="ligneId">Identifiant de la ligne.</param>
        /// <param name="jour">Jour de la semaine.</param>
        /// <param name="heureDebut">Heure de d�but de la plage.</param>
        /// <param name="heureFin">Heure de fin de la plage.</param>
        /// <returns>Liste des horaires.</returns>
        List<Horaire> ObtenirParPlageHoraire(int ligneId, DayOfWeek jour, TimeSpan heureDebut, TimeSpan heureFin);

        /// <summary>
        /// V�rifie l'existence d'un horaire pour une ligne, un arr�t, un jour et une heure donn�s.
        /// </summary>
        /// <param name="ligneId">Identifiant de la ligne.</param>
        /// <param name="arretId">Identifiant de l'arr�t.</param>
        /// <param name="jour">Jour de la semaine.</param>
        /// <param name="heure">Heure de d�part.</param>
        /// <returns>Vrai si l'horaire existe, sinon faux.</returns>
        bool ExisteHoraire(int ligneId, int arretId, DayOfWeek jour, TimeSpan heure);

        /// <summary>
        /// Ajoute un nouvel horaire.
        /// </summary>
        /// <param name="horaire">Horaire � ajouter.</param>
        /// <returns>Identifiant de l'horaire ajout�.</returns>
        int Ajouter(Horaire horaire);

        /// <summary>
        /// Ajoute une liste d'horaires en lot.
        /// </summary>
        /// <param name="horaires">Liste des horaires � ajouter.</param>
        /// <returns>Nombre d'horaires ajout�s.</returns>
        int AjouterEnLot(List<Horaire> horaires);

        /// <summary>
        /// Modifie un horaire existant.
        /// </summary>
        /// <param name="horaire">Horaire � modifier.</param>
        /// <returns>Vrai si la modification a r�ussi, sinon faux.</returns>
        bool Modifier(Horaire horaire);

        /// <summary>
        /// Supprime un horaire par son identifiant.
        /// </summary>
        /// <param name="id">Identifiant de l'horaire � supprimer.</param>
        /// <returns>Vrai si la suppression a r�ussi, sinon faux.</returns>
        bool Supprimer(int id);

        /// <summary>
        /// Supprime les horaires correspondant � des crit�res donn�s.
        /// </summary>
        /// <param name="criteres">Crit�res de suppression.</param>
        /// <returns>Vrai si la suppression a r�ussi, sinon faux.</returns>
        bool SupprimerParCriteres(HoraireCriteres criteres);

        // M�thodes de statistiques

        /// <summary>
        /// Obtient des statistiques du nombre d'horaires par jour pour une ligne donn�e.
        /// </summary>
        /// <param name="ligneId">Identifiant de la ligne.</param>
        /// <returns>Dictionnaire des jours et du nombre d'horaires.</returns>
        Dictionary<DayOfWeek, int> ObtenirStatistiquesParJour(int ligneId);

        /// <summary>
        /// Obtient des statistiques globales par ligne.
        /// </summary>
        /// <returns>Liste des statistiques par ligne.</returns>
        List<HoraireStatistique> ObtenirStatistiquesParLigne();
    }

    /// <summary>
    /// Repr�sente les crit�res de recherche pour les horaires.
    /// </summary>
    public class HoraireCriteres
    {
        /// <summary>
        /// Identifiant de la ligne.
        /// </summary>
        public int? LigneId { get; set; }

        /// <summary>
        /// Identifiant de l'arr�t.
        /// </summary>
        public int? ArretId { get; set; }

        /// <summary>
        /// Jour de la semaine.
        /// </summary>
        public DayOfWeek? JourSemaine { get; set; }

        /// <summary>
        /// Heure de d�but de la plage.
        /// </summary>
        public TimeSpan? HeureDebut { get; set; }

        /// <summary>
        /// Heure de fin de la plage.
        /// </summary>
        public TimeSpan? HeureFin { get; set; }

        /// <summary>
        /// Indique si l'horaire est actif.
        /// </summary>
        public bool? EstActif { get; set; }

        /// <summary>
        /// Date de cr�ation minimale.
        /// </summary>
        public DateTime? DateCreationDebut { get; set; }

        /// <summary>
        /// Date de cr�ation maximale.
        /// </summary>
        public DateTime? DateCreationFin { get; set; }

        /// <summary>
        /// Champ de tri.
        /// </summary>
        public string TrierPar { get; set; } = "HeureDepart";

        /// <summary>
        /// Indique si le tri est d�croissant.
        /// </summary>
        public bool OrdreDecroissant { get; set; } = false;

        /// <summary>
        /// Limite du nombre de r�sultats.
        /// </summary>
        public int? Limite { get; set; }

        /// <summary>
        /// D�calage pour la pagination.
        /// </summary>
        public int? Offset { get; set; }
    }

    /// <summary>
    /// Repr�sente les statistiques d'horaires pour une ligne.
    /// </summary>
    public class HoraireStatistique
    {
        /// <summary>
        /// Identifiant de la ligne.
        /// </summary>
        public int LigneId { get; set; }

        /// <summary>
        /// Nom de la ligne.
        /// </summary>
        public string LigneNom { get; set; }

        /// <summary>
        /// Nombre total d'horaires.
        /// </summary>
        public int NombreHoraires { get; set; }

        /// <summary>
        /// Nombre d'horaires actifs.
        /// </summary>
        public int NombreHorairesActifs { get; set; }

        /// <summary>
        /// Premier horaire de la journ�e.
        /// </summary>
        public TimeSpan? PremierHoraire { get; set; }

        /// <summary>
        /// Dernier horaire de la journ�e.
        /// </summary>
        public TimeSpan? DernierHoraire { get; set; }

        /// <summary>
        /// Fr�quence moyenne des horaires.
        /// </summary>
        public double FrequenceMoyenne { get; set; }
    }
}
