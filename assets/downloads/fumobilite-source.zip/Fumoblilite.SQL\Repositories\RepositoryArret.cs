using System;
using System.Collections.Generic;
using MySql.Data.MySqlClient;
using Fumoblilite.Systeme.Modeles;
using Fumoblilite.Systeme.Interfaces;

namespace Fumoblilite.SQL.Repositories
{
    /// <summary>
    /// Repository pour la gestion des arr�ts dans la base de donn�es MySQL.
    /// </summary>
    public class RepositoryArret : IRepositoryArret
    {
        private readonly string _connectionString;

        /// <summary>
        /// Initialise une nouvelle instance de RepositoryArret avec la cha�ne de connexion sp�cifi�e.
        /// </summary>
        /// <param name="connectionString">Cha�ne de connexion � la base de donn�es.</param>
        public RepositoryArret(string connectionString)
        {
            _connectionString = connectionString;
        }

        /// <summary>
        /// R�cup�re la liste de tous les arr�ts non supprim�s, tri�s par nom.
        /// </summary>
        /// <returns>Liste des arr�ts.</returns>
        public List<Arret> ObtenirTous()
        {
            List<Arret> arrets = new List<Arret>();

            using (MySqlConnection connection = new MySqlConnection(_connectionString))
            {
                connection.Open();
                string query = "SELECT * FROM Arrets WHERE EstSupprime = FALSE ORDER BY Nom";

                using (MySqlCommand command = new MySqlCommand(query, connection))
                {
                    using (MySqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            arrets.Add(MapFromReader(reader));
                        }
                    }
                }
            }

            return arrets;
        }

        /// <summary>
        /// R�cup�re un arr�t par son identifiant s'il n'est pas supprim�.
        /// </summary>
        /// <param name="id">Identifiant de l'arr�t.</param>
        /// <returns>L'arr�t correspondant ou null si non trouv�.</returns>
        public Arret ObtenirParId(int id)
        {
            using (MySqlConnection connection = new MySqlConnection(_connectionString))
            {
                connection.Open();
                string query = "SELECT * FROM Arrets WHERE Id = @Id AND EstSupprime = FALSE";

                using (MySqlCommand command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Id", id);

                    using (MySqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            return MapFromReader(reader);
                        }
                    }
                }
            }

            return null;
        }

        /// <summary>
        /// R�cup�re la liste des arr�ts associ�s � une ligne donn�e.
        /// </summary>
        /// <param name="ligneId">Identifiant de la ligne.</param>
        /// <returns>Liste des arr�ts de la ligne sp�cifi�e.</returns>
        public List<Arret> ObtenirParLigne(int ligneId)
        {
            List<Arret> arrets = new List<Arret>();

            using (MySqlConnection connection = new MySqlConnection(_connectionString))
            {
                connection.Open();
                string query = @"
                        SELECT a.* 
                        FROM Arrets a
                        INNER JOIN ArretsLignes al ON a.Id = al.ArretId
                        WHERE al.LigneId = @LigneId AND a.EstSupprime = FALSE AND al.EstSupprime = FALSE
                        ORDER BY al.Ordre";

                using (MySqlCommand command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@LigneId", ligneId);

                    using (MySqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            arrets.Add(MapFromReader(reader));
                        }
                    }
                }
            }

            return arrets;
        }

        /// <summary>
        /// Ajoute un nouvel arr�t � la base de donn�es.
        /// </summary>
        /// <param name="arret">L'arr�t � ajouter.</param>
        /// <returns>L'identifiant de l'arr�t ajout�.</returns>
        public int Ajouter(Arret arret)
        {
            using (MySqlConnection connection = new MySqlConnection(_connectionString))
            {
                connection.Open();
                string query = @"
                        INSERT INTO Arrets (Nom, Adresse, Latitude, Longitude, EstAccessible, DateCreation, EstSupprime)
                        VALUES (@Nom, @Adresse, @Latitude, @Longitude, @EstAccessible, @DateCreation, FALSE);
                        SELECT LAST_INSERT_ID();";

                using (MySqlCommand command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Nom", arret.Nom);
                    command.Parameters.AddWithValue("@Adresse", arret.Adresse);
                    command.Parameters.AddWithValue("@Latitude", arret.Latitude);
                    command.Parameters.AddWithValue("@Longitude", arret.Longitude);
                    command.Parameters.AddWithValue("@EstAccessible", arret.EstAccessible);
                    command.Parameters.AddWithValue("@DateCreation", arret.DateCreation);

                    return Convert.ToInt32(command.ExecuteScalar());
                }
            }
        }

        /// <summary>
        /// Modifie un arr�t existant dans la base de donn�es.
        /// </summary>
        /// <param name="arret">L'arr�t � modifier.</param>
        /// <returns>True si la modification a r�ussi, sinon false.</returns>
        public bool Modifier(Arret arret)
        {
            using (MySqlConnection connection = new MySqlConnection(_connectionString))
            {
                connection.Open();
                string query = @"
                        UPDATE Arrets 
                        SET Nom = @Nom, 
                            Adresse = @Adresse, 
                            Latitude = @Latitude, 
                            Longitude = @Longitude, 
                            EstAccessible = @EstAccessible, 
                            DateModification = @DateModification
                        WHERE Id = @Id";

                using (MySqlCommand command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Id", arret.Id);
                    command.Parameters.AddWithValue("@Nom", arret.Nom);
                    command.Parameters.AddWithValue("@Adresse", arret.Adresse);
                    command.Parameters.AddWithValue("@Latitude", arret.Latitude);
                    command.Parameters.AddWithValue("@Longitude", arret.Longitude);
                    command.Parameters.AddWithValue("@EstAccessible", arret.EstAccessible);
                    command.Parameters.AddWithValue("@DateModification", arret.DateModification ?? DateTime.Now);

                    return command.ExecuteNonQuery() > 0;
                }
            }
        }

        /// <summary>
        /// Marque un arr�t comme supprim� dans la base de donn�es.
        /// </summary>
        /// <param name="id">Identifiant de l'arr�t � supprimer.</param>
        /// <returns>True si la suppression a r�ussi, sinon false.</returns>
        public bool Supprimer(int id)
        {
            using (MySqlConnection connection = new MySqlConnection(_connectionString))
            {
                connection.Open();
                string query = "UPDATE Arrets SET EstSupprime = TRUE, DateModification = NOW() WHERE Id = @Id";

                using (MySqlCommand command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Id", id);
                    return command.ExecuteNonQuery() > 0;
                }
            }
        }

        /// <summary>
        /// Cr�e un objet Arret � partir d'un MySqlDataReader.
        /// </summary>
        /// <param name="reader">Le lecteur de donn�es MySQL.</param>
        /// <returns>Un objet Arret initialis�.</returns>
        private Arret MapFromReader(MySqlDataReader reader)
        {
            return new Arret
            {
                Id = Convert.ToInt32(reader["Id"]),
                Nom = reader["Nom"].ToString(),
                Adresse = reader["Adresse"] != DBNull.Value ? reader["Adresse"].ToString() : null,
                Latitude = Convert.ToDouble(reader["Latitude"]),
                Longitude = Convert.ToDouble(reader["Longitude"]),
                EstAccessible = Convert.ToBoolean(reader["EstAccessible"]),
                DateCreation = Convert.ToDateTime(reader["DateCreation"]),
                DateModification = reader["DateModification"] != DBNull.Value ? (DateTime?)Convert.ToDateTime(reader["DateModification"]) : null
            };
        }
    }
}
