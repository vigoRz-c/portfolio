using System.Collections.Generic;
using Fumoblilite.Systeme.Modeles;

namespace Fumoblilite.Systeme.Interfaces
{
    /// <summary>
    /// Interface pour la gestion des op�rations CRUD sur les arr�ts.
    /// </summary>
    public interface IRepositoryArret
    {
        /// <summary>
        /// R�cup�re la liste de tous les arr�ts.
        /// </summary>
        /// <returns>Liste de tous les arr�ts.</returns>
        List<Arret> ObtenirTous();

        /// <summary>
        /// R�cup�re un arr�t par son identifiant.
        /// </summary>
        /// <param name="id">Identifiant de l'arr�t.</param>
        /// <returns>L'arr�t correspondant � l'identifiant, ou null si non trouv�.</returns>
        Arret ObtenirParId(int id);

        /// <summary>
        /// R�cup�re la liste des arr�ts associ�s � une ligne donn�e.
        /// </summary>
        /// <param name="ligneId">Identifiant de la ligne.</param>
        /// <returns>Liste des arr�ts de la ligne sp�cifi�e.</returns>
        List<Arret> ObtenirParLigne(int ligneId);

        /// <summary>
        /// Ajoute un nouvel arr�t.
        /// </summary>
        /// <param name="arret">L'arr�t � ajouter.</param>
        /// <returns>L'identifiant de l'arr�t ajout�.</returns>
        int Ajouter(Arret arret);

        /// <summary>
        /// Modifie un arr�t existant.
        /// </summary>
        /// <param name="arret">L'arr�t � modifier.</param>
        /// <returns>True si la modification a r�ussi, sinon false.</returns>
        bool Modifier(Arret arret);

        /// <summary>
        /// Supprime un arr�t par son identifiant.
        /// </summary>
        /// <param name="id">Identifiant de l'arr�t � supprimer.</param>
        /// <returns>True si la suppression a r�ussi, sinon false.</returns>
        bool Supprimer(int id);
    }
}

