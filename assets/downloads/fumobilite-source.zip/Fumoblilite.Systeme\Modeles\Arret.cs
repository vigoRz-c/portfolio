using System;

namespace Fumoblilite.Systeme.Modeles
{
    /// <summary>
    /// Mod�le de donn�es pour un arr�t
    /// </summary>
    public class Arret
    {
        public int Id { get; set; } // Identifiant de l'arr�t
        public string Nom { get; set; } // Nom de l'arr�t
        public string Adresse { get; set; } // Adresse de l'arr�t
        public double Latitude { get; set; } // Latitude de l'arr�t
        public double Longitude { get; set; } // Longitude de l'arr�t
        public bool EstAccessible { get; set; } // Accessibilit� de l'arr�t
        public DateTime DateCreation { get; set; } // Date de cr�ation de l'arr�t
        public DateTime? DateModification { get; set; } // Date de modification de l'arr�t

        /// <summary>
        /// Constructeur par d�faut. Initialise la date de cr�ation � la date et l'heure actuelles.
        /// </summary>
        public Arret()
        {
            DateCreation = DateTime.Now;
        }

        /// <summary>
        /// Constructeur avec param�tres pour initialiser toutes les propri�t�s sauf la date de modification.
        /// </summary>
        /// <param name="id">Identifiant de l'arr�t</param>
        /// <param name="nom">Nom de l'arr�t</param>
        /// <param name="adresse">Adresse de l'arr�t</param>
        /// <param name="latitude">Latitude de l'arr�t</param>
        /// <param name="longitude">Longitude de l'arr�t</param>
        /// <param name="estAccessible">Indique si l'arr�t est accessible</param>
        public Arret(int id, string nom, string adresse, double latitude, double longitude, bool estAccessible)
        {
            Id = id;
            Nom = nom;
            Adresse = adresse;
            Latitude = latitude;
            Longitude = longitude;
            EstAccessible = estAccessible;
            DateCreation = DateTime.Now;
        }
    }
}

